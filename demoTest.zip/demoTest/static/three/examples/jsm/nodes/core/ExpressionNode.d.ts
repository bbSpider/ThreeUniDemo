import { FunctionNode } from './FunctionNode';

export class ExpressionNode extends FunctionNode {

	constructor( src: string, type?: string, keywords?: object, extensions?: object, includes?: object[] );

}
